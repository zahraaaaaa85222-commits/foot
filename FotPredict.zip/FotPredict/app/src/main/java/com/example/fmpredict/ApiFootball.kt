package com.example.fmpredict

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

data class Team(val id: Int, val name: String)
data class FixtureRef(val id: Int, val ts: Long)

/** آمار نیمه اول هر تیم در یک بازی. exact=false یعنی از آمار کل بازی با سهم معمول نیمه اول تخمین زده شده */
data class FxStats(val exact: Boolean, val byTeam: Map<Int, Map<String, Double>>)

/**
 * دسترسی رسمی به API-Football (api-sports.io) با کلید شخصی.
 * رعایت سقف درخواست: حداقل ۱٫۵ ثانیه فاصله بین درخواست‌ها، و ذخیره‌ی آمار بازی‌های تمام‌شده
 * روی گوشی تا یک بازی دوبار از سرور گرفته نشود.
 */
object ApiFootball {
    private const val BASE = "https://v3.football.api-sports.io"
    private val client = OkHttpClient()
    private lateinit var prefs: SharedPreferences
    private var lastCall = 0L

    var remaining: String = "؟"
    var lastRaw: String = ""

    // سهم معمول نیمه اول از کل بازی (تخمین؛ فقط وقتی API آمار نیمه‌ای نداد)
    val SHARE = mapOf("corners" to 0.46, "fouls" to 0.47, "yellow" to 0.38, "goalkicks" to 0.48)

    fun init(ctx: Context) { prefs = ctx.getSharedPreferences("fp", Context.MODE_PRIVATE) }
    fun key(): String = prefs.getString("key", "") ?: ""
    fun saveKey(k: String) { prefs.edit().putString("key", k.trim()).apply() }

    private suspend fun get(path: String): JSONObject = withContext(Dispatchers.IO) {
        if (key().isEmpty()) error("اول کلید API را وارد کن.")
        val wait = 1500 - (System.currentTimeMillis() - lastCall)
        if (wait > 0) delay(wait)
        lastCall = System.currentTimeMillis()
        val req = Request.Builder().url(BASE + path).header("x-apisports-key", key()).build()
        client.newCall(req).execute().use { r ->
            r.header("x-ratelimit-requests-remaining")?.let { remaining = it }
            if (r.code == 429) error("سقف درخواست پر شد؛ کمی بعد یا فردا دوباره امتحان کن.")
            val txt = r.body?.string() ?: error("پاسخ خالی")
            val j = JSONObject(txt)
            val msg = when (val e = j.opt("errors")) {
                is JSONObject -> e.keys().asSequence().joinToString("; ") { "$it: ${e.optString(it)}" }
                is JSONArray -> if (e.length() > 0) e.toString() else ""
                else -> ""
            }
            if (msg.isNotEmpty()) error(msg)
            j
        }
    }

    suspend fun searchTeams(q: String): List<Team> {
        if (q.trim().length < 3) error("حداقل ۳ حرف انگلیسی بنویس.")
        val arr = get("/teams?search=" + URLEncoder.encode(q.trim(), "UTF-8")).optJSONArray("response")
            ?: return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            arr.optJSONObject(i)?.optJSONObject("team")?.let { Team(it.optInt("id"), it.optString("name")) }
        }.take(6)
    }

    /** آخرین بازی‌های تمام‌شده؛ جدیدترین اول */
    suspend fun lastFixtures(teamId: Int, n: Int): List<FixtureRef> {
        val arr = get("/fixtures?team=$teamId&last=$n").optJSONArray("response") ?: return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            val f = arr.optJSONObject(i)?.optJSONObject("fixture") ?: return@mapNotNull null
            FixtureRef(f.optInt("id"), f.optLong("timestamp"))
        }.sortedByDescending { it.ts }
    }

    private fun classify(type: String): String? {
        val t = type.lowercase()
        return when {
            "corner" in t -> "corners"
            "foul" in t -> "fouls"
            "yellow" in t -> "yellow"
            "goal kick" in t || "goal_kick" in t -> "goalkicks"
            else -> null
        }
    }

    private fun num(x: Any?): Double? = when (x) {
        is Number -> x.toDouble()
        is String -> x.removeSuffix("%").toDoubleOrNull()
        else -> null
    }

    suspend fun fixtureStats(ref: FixtureRef): FxStats? {
        prefs.getString("fx_${ref.id}", null)?.let { return decode(it) }
        val j = get("/fixtures/statistics?fixture=${ref.id}&half=true")
        if (lastRaw.isEmpty()) lastRaw = j.toString().take(1800)
        val arr = j.optJSONArray("response") ?: return null
        if (arr.length() < 2) return null
        var exact = true
        val out = HashMap<Int, Map<String, Double>>()
        for (i in 0 until arr.length()) {
            val e = arr.optJSONObject(i) ?: continue
            val tid = e.optJSONObject("team")?.optInt("id") ?: continue
            var full: JSONArray? = null
            var half: JSONArray? = null
            e.keys().forEach { k ->
                val v = e.opt(k)
                val low = k.lowercase()
                if (v is JSONArray && "stat" in low) {
                    if ("1h" in low || "first" in low) half = v else if (low == "statistics") full = v
                }
            }
            val src = half ?: full ?: continue
            if (half == null) exact = false
            val m = HashMap<String, Double>()
            for (s in 0 until src.length()) {
                val item = src.optJSONObject(s) ?: continue
                val key = classify(item.optString("type")) ?: continue
                val v = num(item.opt("value")) ?: 0.0
                m[key] = if (half != null) v else v * (SHARE[key] ?: 0.46)
            }
            out[tid] = m
        }
        if (out.size < 2) return null
        val fx = FxStats(exact, out)
        prefs.edit().putString("fx_${ref.id}", encode(fx)).apply() // بازی تمام‌شده تغییر نمی‌کند
        return fx
    }

    private fun encode(fx: FxStats): String {
        val o = JSONObject().put("exact", fx.exact)
        val t = JSONObject()
        fx.byTeam.forEach { (id, m) -> t.put(id.toString(), JSONObject(m as Map<*, *>)) }
        return o.put("t", t).toString()
    }

    private fun decode(s: String): FxStats {
        val o = JSONObject(s)
        val t = o.getJSONObject("t")
        val m = HashMap<Int, Map<String, Double>>()
        t.keys().forEach { id ->
            val inner = t.getJSONObject(id)
            m[id.toInt()] = inner.keys().asSequence().associateWith { inner.getDouble(it) }
        }
        return FxStats(o.optBoolean("exact", false), m)
    }
}
