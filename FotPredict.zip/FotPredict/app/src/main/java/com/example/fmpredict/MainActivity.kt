package com.example.fmpredict

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.floor
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ApiFootball.init(applicationContext)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme { Surface(Modifier.fillMaxSize()) { Screen() } }
            }
        }
    }
}

private fun f1(x: Double) = String.format(Locale.US, "%.1f", x)

@Composable
fun TeamPicker(label: String, selected: Team?, onSelect: (Team) -> Unit) {
    val scope = rememberCoroutineScope()
    var q by remember { mutableStateOf("") }
    var results by remember { mutableStateOf(listOf<Team>()) }
    var err by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = q, onValueChange = { q = it }, singleLine = true,
                label = { Text(if (selected != null) "$label: ${selected.name}" else "$label (انگلیسی)") },
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = {
                scope.launch {
                    err = null
                    try { results = ApiFootball.searchTeams(q) } catch (e: Exception) { err = e.message }
                }
            }) { Text("جستجو") }
        }
        err?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp) }
        results.forEach { t ->
            TextButton(onClick = { onSelect(t); results = emptyList(); q = "" }) { Text(t.name) }
        }
    }
}

@Composable
fun Screen() {
    val scope = rememberCoroutineScope()
    var key by remember { mutableStateOf(ApiFootball.key()) }
    var home by remember { mutableStateOf<Team?>(null) }
    var away by remember { mutableStateOf<Team?>(null) }
    var last by remember { mutableStateOf("6") }
    var status by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var estimated by remember { mutableStateOf(false) }
    var showRaw by remember { mutableStateOf(false) }
    var results by remember { mutableStateOf(listOf<StatResult>()) }

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("پیش‌بینی آمار نیمه اول", fontSize = 24.sp, fontWeight = FontWeight.Bold) }
        item {
            OutlinedTextField(
                value = key, onValueChange = { key = it; ApiFootball.saveKey(it) },
                label = { Text("کلید API-Football") }, singleLine = true, modifier = Modifier.fillMaxWidth()
            )
        }
        item { TeamPicker("تیم میزبان", home) { home = it } }
        item { TeamPicker("تیم مهمان", away) { away = it } }
        item {
            OutlinedTextField(
                value = last, onValueChange = { last = it.filter(Char::isDigit).take(2) },
                label = { Text("تعداد بازی اخیر (کمتر = مصرف کمتر سهمیه)") }, singleLine = true
            )
        }
        item {
            Button(
                enabled = home != null && away != null && !busy,
                onClick = {
                    scope.launch {
                        busy = true; results = emptyList(); ApiFootball.lastRaw = ""
                        try {
                            val n = (last.toIntOrNull() ?: 6).coerceIn(3, 15)
                            val h = teamAverages(home!!, n) { status = it }
                            val a = teamAverages(away!!, n) { status = it }
                            results = combine(h.avgs, a.avgs)
                            estimated = !(h.allExact && a.allExact)
                            status = if (results.isEmpty()) "آمار نیمه اول پیدا نشد (جزئیات فنی را ببین)." else "انجام شد."
                        } catch (e: Exception) { status = "خطا: ${e.message}" }
                        busy = false
                    }
                }
            ) { Text("تحلیل بازی") }
        }
        if (status.isNotEmpty()) item { Text(status, fontSize = 13.sp) }
        item { Text("درخواست باقی‌مانده امروز: ${ApiFootball.remaining}", fontSize = 12.sp) }
        if (results.isNotEmpty() && estimated) item {
            Text("توجه: آمار جدا برای نیمه اول از API نیامد؛ سهم نیمه اول از آمار کل بازی با نسبت‌های معمول تخمین زده شد.",
                fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
        }
        items(results) { r ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Text(r.title, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("${home?.name}: ${f1(r.lamHome)}   ${away?.name}: ${f1(r.lamAway)}")
                    Text("مجموع مورد انتظار: ${f1(r.total)}", fontWeight = FontWeight.SemiBold)
                    val base = floor(r.total).toInt()
                    val lines = (base - 1..base + 2).filter { it >= 0 }.map { it + 0.5 }
                    Text(lines.joinToString("  |  ") { l ->
                        "O${f1(l)}: ${(overProb(l, r.total) * 100).roundToInt()}%"
                    }, fontSize = 13.sp)
                }
            }
        }
        item { TextButton(onClick = { showRaw = !showRaw }) { Text("جزئیات فنی (برای عیب‌یابی)") } }
        if (showRaw) item { Text(ApiFootball.lastRaw.ifEmpty { "هنوز پاسخی دریافت نشده." }, fontSize = 10.sp) }
        item {
            Text("تخمین آماری است و تضمینی نیست. اگر API آمار ضربه دروازه نداشته باشد، آن بخش نمایش داده نمی‌شود.", fontSize = 11.sp)
        }
    }
}
