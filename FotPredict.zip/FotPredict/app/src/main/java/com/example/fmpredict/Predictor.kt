package com.example.fmpredict

import kotlin.math.exp
import kotlin.math.floor

val STAT_TITLES = linkedMapOf(
    "corners" to "کرنر", "fouls" to "خطا", "yellow" to "کارت زرد", "goalkicks" to "ضربه دروازه"
)

data class Avg(val gf: Double, val ga: Double, val n: Int)
data class TeamResult(val avgs: Map<String, Avg>, val allExact: Boolean)
data class StatResult(val title: String, val lamHome: Double, val lamAway: Double) {
    val total get() = lamHome + lamAway
}

/** میانگین وزنی «می‌گیرد/می‌دهد» در نیمه اول؛ بازی‌های جدیدتر وزن بیشتر */
suspend fun teamAverages(
    team: Team, last: Int, decay: Double = 0.92, progress: (String) -> Unit
): TeamResult {
    val refs = ApiFootball.lastFixtures(team.id, last)
    val w = HashMap<String, Double>(); val f = HashMap<String, Double>()
    val a = HashMap<String, Double>(); val c = HashMap<String, Int>()
    var exact = true
    refs.forEachIndexed { i, ref ->
        progress("${team.name}: بازی ${i + 1} از ${refs.size}")
        val fx = ApiFootball.fixtureStats(ref)
        val mine = fx?.byTeam?.get(team.id)
        val other = fx?.byTeam?.entries?.firstOrNull { it.key != team.id }?.value
        if (fx != null && mine != null && other != null) {
            if (!fx.exact) exact = false
            val wt = Math.pow(decay, i.toDouble())
            for ((k, got) in mine) {
                val conc = other[k] ?: continue
                w[k] = (w[k] ?: 0.0) + wt
                f[k] = (f[k] ?: 0.0) + wt * got
                a[k] = (a[k] ?: 0.0) + wt * conc
                c[k] = (c[k] ?: 0) + 1
            }
        }
    }
    return TeamResult(w.keys.associateWith { Avg(f[it]!! / w[it]!!, a[it]!! / w[it]!!, c[it]!!) }, exact)
}

fun combine(home: Map<String, Avg>, away: Map<String, Avg>): List<StatResult> =
    STAT_TITLES.mapNotNull { (k, title) ->
        val h = home[k]; val a = away[k]
        if (h == null || a == null) null
        else StatResult(title, (h.gf + a.ga) / 2, (a.gf + h.ga) / 2)
    }

fun poissonCdf(k: Int, lam: Double): Double {
    var p = exp(-lam); var s = p
    for (i in 1..k) { p *= lam / i; s += p }
    return minOf(s, 1.0)
}

fun overProb(line: Double, lam: Double) = 1 - poissonCdf(floor(line).toInt(), lam)
